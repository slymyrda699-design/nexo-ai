import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Home, Clapperboard, Folder, Crown, Headphones, Settings, Bell, Gem, Plus, Sparkles, Image, Clock, Palette, WandSparkles, Play, Download, Menu, X, Film, CheckCircle2 } from 'lucide-react';
import './style.css';

function App() {
  const [mode, setMode] = useState('text');
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('سینمایی');
  const [duration, setDuration] = useState('۵ ثانیه');
  const [ratio, setRatio] = useState('۱۶:۹');
  const [notice, setNotice] = useState('');
  const [projects, setProjects] = useState([
    {name:'غروب در شهر آینده', kind:'نمونه نمایشی', time:'۰۰:۰۵', art:'city'},
    {name:'گربه در باغ گل‌ها', kind:'نمونه نمایشی', time:'۰۰:۰۵', art:'cat'},
    {name:'جنگجوی افسانه‌ای', kind:'نمونه نمایشی', time:'۰۰:۰۷', art:'warrior'}
  ]);
  const [mobileOpen, setMobileOpen] = useState(false);

  function startDemo() {
    if (!prompt.trim()) { setNotice('اول توضیح ویدئویی را بنویس.'); return; }
    setNotice('در نسخه آزمایشی، فرم آماده است؛ برای تولید واقعی باید سرویس ویدئوساز و کلید API متصل شود.');
  }
  function uploadImage(e) {
    const f = e.target.files?.[0];
    if (f) setNotice(`تصویر «${f.name}» انتخاب شد. اتصال تولید عکس به ویدئو در مرحله بعد انجام می‌شود.`);
  }

  return <div className="app" dir="rtl">
    <header className="topbar">
      <button className="mobile-menu" onClick={()=>setMobileOpen(!mobileOpen)} aria-label="منو">{mobileOpen?<X/>:<Menu/>}</button>
      <div className="brand"><span className="brand-mark">N</span><span>NEXO <b>AI</b></span></div>
      <nav className={mobileOpen?'nav open':'nav'}>
        <a className="active"><Home size={18}/> خانه</a><a><Clapperboard size={18}/> ساخت ویدئو</a><a><Folder size={18}/> پروژه‌های من</a><a><Crown size={18}/> پلن‌ها</a>
      </nav>
      <div className="account"><button className="icon-btn"><Bell size={19}/></button><div className="credits"><Gem size={18}/> <span>۱۰۰ اعتبار آزمایشی</span><Plus size={18}/></div><div className="avatar">R</div></div>
    </header>

    <main>
      <section className="hero">
        <div className="hero-copy"><div className="eyebrow"><Sparkles size={15}/> خلاقیت، بدون محدودیت</div><h1>ایده‌ات رو به <em>ویدئو</em> تبدیل کن</h1><p>با NEXO AI برای ساخت ویدئوهای خلاقانه آماده شو.</p></div>
        <div className="hero-orb"><div className="orb-ring"></div><Film size={76}/><span className="spark s1">✦</span><span className="spark s2">✧</span></div>
      </section>

      <section className="workspace">
        <div className="creator panel">
          <div className="tabs">
            <button className={mode==='text'?'tab selected':'tab'} onClick={()=>{setMode('text');setNotice('')}}><Clapperboard size={18}/> متن به ویدئو</button>
            <button className={mode==='image'?'tab selected':'tab'} onClick={()=>{setMode('image');setNotice('')}}><Image size={18}/> عکس به ویدئو</button>
          </div>
          {mode==='text' ? <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="توصیف کن چه ویدئویی می‌خواهی بسازی... مثلاً: نمای سینمایی از یک شهر آینده در زمان غروب، نورهای نئونی و پرواز خودروها" /> :
            <label className="upload"><Image size={30}/><b>برای انتخاب تصویر کلیک کن</b><span>PNG یا JPG</span><input type="file" accept="image/png,image/jpeg,image/webp" onChange={uploadImage}/></label>}
          <div className="settings">
            <label><span><Palette size={15}/> سبک ویدئو</span><select value={style} onChange={e=>setStyle(e.target.value)}><option>سینمایی</option><option>واقع‌گرایانه</option><option>انیمیشن</option><option>فانتزی</option><option>مستند</option></select></label>
            <label><span><Clock size={15}/> مدت زمان</span><select value={duration} onChange={e=>setDuration(e.target.value)}><option>۵ ثانیه</option><option>۱۰ ثانیه</option><option>۱۵ ثانیه</option></select></label>
            <label><span><Image size={15}/> نسبت تصویر</span><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>۱۶:۹</option><option>۹:۱۶</option><option>۱:۱</option></select></label>
          </div>
          <button className="generate" onClick={startDemo}><WandSparkles size={20}/> ساخت ویدئو <span>→</span></button>
          {notice && <div className="notice"><CheckCircle2 size={17}/>{notice}</div>}
          <p className="disclaimer">نسخه اولیه رابط کاربری است؛ تولید واقعی پس از اتصال سرویس ویدئوساز فعال می‌شود.</p>
        </div>
        <div className="preview panel">
          <div className="preview-head"><span>پیش‌نمایش</span><span className="live-dot">نمونه نمایشی</span></div>
          <div className="preview-art">
            <div className="sun"></div><div className="skyline"><i></i><i></i><i></i><i></i><i></i><i></i></div>
            <div className="road"></div><div className="preview-play"><Play fill="currentColor" size={27}/></div>
            <div className="preview-caption">NEXO AI · VIDEO STUDIO</div>
          </div>
          <div className="preview-foot"><span>نمونه طراحی محیط پیش‌نمایش</span><span>00:00 / 00:05</span></div>
        </div>
      </section>

      <section className="projects">
        <div className="section-head"><div><span className="eyebrow"><Folder size={15}/> کتابخانه</span><h2>پروژه‌های اخیر</h2></div><button className="ghost">مشاهده همه <span>←</span></button></div>
        <div className="project-grid">{projects.map((p,i)=><article className="project-card" key={i}><div className={'thumb '+p.art}><span className="thumb-play"><Play size={17} fill="currentColor"/></span><span className="duration">{p.time}</span></div><div className="project-info"><div><b>{p.name}</b><small>{p.kind}</small></div><button className="icon-btn"><Download size={17}/></button></div></article>)}</div>
      </section>
      <footer><div className="brand small"><span className="brand-mark">N</span><span>NEXO <b>AI</b></span></div><span>از ایده تا تصویر، با NEXO AI</span><span>نسخه آزمایشی ۰.۱</span></footer>
    </main>
  </div>
}
createRoot(document.getElementById('root')).render(<App/>);
